plugins {
    id("com.android.library") version "7.0.2"
    kotlin("android") version "1.5.20"
    kotlin("kapt") version "1.5.20"
    kotlin("plugin.serialization") version "1.5.20"
}

android {
    compileSdk = 31
    buildToolsVersion = "30.0.3"
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_1_8.toString()
        freeCompilerArgs = listOf(
            "-Xallow-result-return-type",
            "-Xopt-in=kotlin.RequiresOptIn",
            "-Xopt-in=kotlin.contracts.ExperimentalContracts"
        )
    }
//
//    tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile> {
//        kotlinOptions {
//            jvmTarget = "1.8"
//        }
//    }

    defaultConfig {
//        applicationId = "dev.patrickgold.florisboard"
        minSdk = 23
        targetSdk = 31

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"


    }


//    externalNativeBuild {
//        cmake {
//            path("src/main/cpp/CMakeLists.txt")
//        }
//    }

    buildTypes {
        getByName("debug") {

//            resValue("mipmap", "floris_app_icon", "@mipmap/ic_app_icon_debug")
//            resValue("mipmap", "floris_app_icon_round", "@mipmap/ic_app_icon_debug_round")
//            resValue("string", "floris_app_name", "FlorisBoard Debug")

            proguardFiles.add(getDefaultProguardFile("proguard-android-optimize.txt"))


        }


        getByName("release") {

//            resValue("mipmap", "floris_app_icon", "@mipmap/ic_app_icon_release")
//            resValue("mipmap", "floris_app_icon_round", "@mipmap/ic_app_icon_release_round")
//            resValue("string", "floris_app_name", "@string/app_name")

            proguardFiles.add(getDefaultProguardFile("proguard-android-optimize.txt"))
        }
    }

    testOptions {
        unitTests {
            isIncludeAndroidResources = true
        }
    }

    lint {
        isAbortOnError = false
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.activity", "activity-ktx", "1.2.1")

    api("androidx.appcompat", "appcompat", "1.4.0")
    api("androidx.constraintlayout", "constraintlayout", "2.1.2")
    api("com.google.android.material", "material", "1.4.0")

    api("androidx.lifecycle", "lifecycle-service", "2.2.0")
    api("org.jetbrains.kotlinx", "kotlinx-coroutines-android", "1.4.2")
    api("org.jetbrains.kotlinx", "kotlinx-serialization-json", "1.1.0")
    api("androidx.preference", "preference-ktx", "1.1.1")
    api("com.jakewharton.timber", "timber", "4.7.1")


    api("androidx.room", "room-ktx", "2.4.0-beta02")
    api("androidx.legacy:legacy-support-v4:1.0.0")
    kapt("androidx.room", "room-compiler", "2.4.0-beta02")


    implementation("androidx.autofill", "autofill", "1.1.0")
    implementation("androidx.core", "core-ktx", "1.3.2")
    implementation("androidx.fragment", "fragment-ktx", "1.3.0")
    implementation("com.google.android.flexbox", "flexbox", "3.0.0")
    implementation("com.jaredrummler", "colorpicker", "1.1.0")
    implementation("com.nambimobile.widgets", "expandable-fab", "1.0.2")
    testImplementation(kotlin("test"))
    testImplementation("androidx.test", "core", "1.3.0")
}
