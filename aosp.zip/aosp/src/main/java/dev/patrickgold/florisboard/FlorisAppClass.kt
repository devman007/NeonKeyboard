package dev.patrickgold.florisboard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import androidx.core.os.UserManagerCompat
import dev.patrickgold.florisboard.crashutility.CrashUtility
import dev.patrickgold.florisboard.debug.Flog
import dev.patrickgold.florisboard.debug.LogTopic
import dev.patrickgold.florisboard.ime.core.Preferences
import dev.patrickgold.florisboard.ime.core.SubtypeManager
import dev.patrickgold.florisboard.ime.theme.ThemeManager
import dev.patrickgold.florisboard.res.AssetManager
import timber.log.Timber

class FlorisAppClass(private val context: Context) {


    fun onCreate() {
        try {
            if (BuildConfig.DEBUG) {
                Timber.plant(Timber.DebugTree())
            }
            Flog.install(
                applicationContext = context,
                isFloggingEnabled = BuildConfig.DEBUG,
                flogTopics = LogTopic.ALL,
                flogLevels = Flog.LEVEL_ALL,
                flogOutputs = Flog.OUTPUT_CONSOLE
            )
//            initICU()
            CrashUtility.install(context)
            val prefs = Preferences.initDefault(context)
            val assetManager = AssetManager.init(context)
            SubtypeManager.init(context)
            ThemeManager.init(context, assetManager)
            prefs.initDefaultPreferences()
        } catch (e: Exception) {
            CrashUtility.stageException(e)
            return
        }

        /*Register a receiver so user config can be applied once device protracted storage is available*/
        if (!UserManagerCompat.isUserUnlocked(context) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            context.registerReceiver(BootComplete(), IntentFilter(Intent.ACTION_USER_UNLOCKED))
        }
    }

//    fun initICU(): Boolean {
//        try {
//            val context = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
//                context.createDeviceProtectedStorageContext()
//            } else {
//                context
//            }
//            val androidAssetManager = context.assets ?: return false
//            val dstDataFile = File(context.cacheDir, "icudt.dat")
//            dstDataFile.outputStream().use { os ->
//                androidAssetManager.open(ICU_DATA_ASSET_PATH).use { it.copyTo(os) }
//            }
//            val status = nativeInitICUData(dstDataFile.absolutePath.toNativeStr())
//            return if (status != 0) {
//                flogError { "Native ICU data initializing failed with error code $status!" }
//                false
//            } else {
//                flogInfo { "Successfully loaded ICU data!" }
//                true
//            }
//        } catch (e: Exception) {
//            flogError { e.toString() }
//            return false
//        }
//    }

    fun init() {
        CrashUtility.install(context)
        val prefs = Preferences.initDefault(context)
        val assetManager = AssetManager.init(context)
        SubtypeManager.init(context)
//        DictionaryManager.init(context)
        ThemeManager.init(context, assetManager)
        prefs.initDefaultPreferences()
    }

    private inner class BootComplete : BroadcastReceiver() {

        override fun onReceive(context: Context?, intent: Intent?) {
            if (Intent.ACTION_USER_UNLOCKED == intent?.action) {
                try {
                    context?.unregisterReceiver(this)
                    init()
                } catch (e: Exception) {
                    e.fillInStackTrace()
                }
            }
        }
    }
}